import { useEffect, useState } from "react";
import { Cloud, Loader2, KeyRound, CheckCircle2, XCircle, Link as LinkIcon, Copy, Pencil, ShieldCheck, ShieldAlert, AlertTriangle, Wand2, Lock } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

// ---------------- Self-diagnostic helpers ----------------

type Diagnosis = {
  code:
    | "ok"
    | "pem_missing_headers"
    | "pem_bad_base64"
    | "pem_wrong_type"
    | "auth_failed"
    | "not_found"
    | "network_cors"
    | "server_error"
    | "rate_limited"
    | "unknown";
  title: string;
  detail: string;
  fix: string;
};

function diagnose(raw: string | undefined, httpHint?: number): Diagnosis {
  const msg = (raw ?? "").toString();
  const m = msg.toLowerCase();
  const statusMatch = msg.match(/\b(4\d\d|5\d\d)\b/);
  const status = httpHint ?? (statusMatch ? Number(statusMatch[1]) : undefined);

  if (m.includes("pem") && (m.includes("header") || m.includes("begin") || m.includes("end"))) {
    return {
      code: "pem_missing_headers",
      title: "Invalid PEM format · missing BEGIN/END headers",
      detail: "The private key is missing the -----BEGIN PRIVATE KEY----- / -----END PRIVATE KEY----- boundary lines.",
      fix: "Click Auto-format key, or repaste the full PEM block from OCI exactly as downloaded.",
    };
  }
  if (m.includes("pkcs1") || m.includes("rsa private key")) {
    return {
      code: "pem_wrong_type",
      title: "Wrong key format · expected PKCS#8",
      detail: "OCI requires a PKCS#8 PEM. You appear to have pasted a PKCS#1 (BEGIN RSA PRIVATE KEY) key.",
      fix: "Convert it: openssl pkcs8 -topk8 -nocrypt -in key.pem -out key-pkcs8.pem and paste the new file.",
    };
  }
  if (m.includes("base64") || m.includes("decode") || m.includes("invalid key")) {
    return {
      code: "pem_bad_base64",
      title: "PEM body could not be decoded",
      detail: "The key body contains stray characters or was truncated during copy/paste.",
      fix: "Re-download the key from OCI and paste the entire file — including the header and footer lines.",
    };
  }
  if (status === 401 || status === 403 || m.includes("unauthor") || m.includes("not author") || m.includes("forbidden") || m.includes("signature")) {
    return {
      code: "auth_failed",
      title: "Authentication failed · check Fingerprint / OCIDs",
      detail: `OCI rejected the signed request${status ? ` (HTTP ${status})` : ""}. The Tenancy OCID, User OCID, or Fingerprint likely does not match the uploaded public key.`,
      fix: "Open the OCI console → User → API Keys. Confirm the fingerprint matches and the public key is active.",
    };
  }
  if (status === 404 || m.includes("not found") || m.includes("notfound") || (m.includes("bucket") && m.includes("does not exist"))) {
    return {
      code: "not_found",
      title: "Bucket or namespace not found",
      detail: "OCI returned 404 — the bucket name or namespace is wrong, or the bucket lives in a different region.",
      fix: "Verify Namespace (Tenancy → Object Storage Namespace) and Bucket name. Check the Region matches the bucket.",
    };
  }
  if (status === 429 || m.includes("rate") || m.includes("throttl")) {
    return {
      code: "rate_limited",
      title: "OCI rate-limited the request",
      detail: "Too many calls in a short window.",
      fix: "Wait 30–60 seconds and re-test.",
    };
  }
  if (m.includes("network") || m.includes("cors") || m.includes("fetch") || m.includes("failed to fetch") || m.includes("dns")) {
    return {
      code: "network_cors",
      title: "Network / CORS blocked",
      detail: "The browser or edge function could not reach objectstorage.<region>.oraclecloud.com.",
      fix: "Check connectivity, then confirm the bucket CORS rules allow this origin. If the edge function failed, retry — it may be cold-starting.",
    };
  }
  if (status && status >= 500) {
    return {
      code: "server_error",
      title: `OCI server error (HTTP ${status})`,
      detail: "Oracle Object Storage reported a transient server-side issue.",
      fix: "Retry in a minute. If it persists, check the OCI status page.",
    };
  }
  if (m && m !== "unknown error") {
    return {
      code: "unknown",
      title: "Verification failed",
      detail: msg,
      fix: "Re-check every field, then click Re-test connection. Use Edit credentials if anything looks off.",
    };
  }
  return {
    code: "unknown",
    title: "Verification failed",
    detail: "No additional detail returned by the proxy.",
    fix: "Open browser devtools → Network → oracle-proxy to inspect the response, then retry.",
  };
}

/**
 * Tidies a pasted OCI private key:
 *  - strips zero-width chars, BOMs, smart quotes
 *  - normalises CRLF → LF
 *  - re-wraps base64 body to 64-char lines
 *  - guarantees -----BEGIN/END PRIVATE KEY----- boundaries
 */
function autoFormatPem(input: string): { pem: string; changed: boolean; valid: boolean; reason?: string } {
  const original = input ?? "";
  if (!original.trim()) return { pem: "", changed: false, valid: false, reason: "Empty input" };

  let s = original
    .replace(/\uFEFF/g, "")
    .replace(/[\u200B-\u200D]/g, "")
    .replace(/[\u2018\u2019\u201C\u201D]/g, "")
    .replace(/\r\n/g, "\n")
    .replace(/\r/g, "\n")
    .trim();

  if (/-----BEGIN RSA PRIVATE KEY-----/i.test(s)) {
    return { pem: s, changed: s !== original, valid: false, reason: "PKCS#1 key detected — convert to PKCS#8" };
  }

  const headerRe = /-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----/i;
  const footerRe = /-----END [A-Z0-9 ]*PRIVATE KEY-----/i;
  let body: string;
  if (headerRe.test(s) && footerRe.test(s)) {
    body = s.replace(headerRe, "").replace(footerRe, "");
  } else {
    body = s;
  }
  body = body.replace(/[^A-Za-z0-9+/=]/g, "");
  if (body.length < 200) {
    return { pem: original, changed: false, valid: false, reason: "Key body looks too short — re-paste full PEM" };
  }
  const wrapped = body.match(/.{1,64}/g)!.join("\n");
  const pem = `-----BEGIN PRIVATE KEY-----\n${wrapped}\n-----END PRIVATE KEY-----\n`;
  return { pem, changed: pem !== original, valid: true };
}


type OracleConfig = {
  oracle_tenancy_ocid: string;
  oracle_user_ocid: string;
  oracle_fingerprint: string;
  oracle_region: string;
  oracle_namespace: string;
  oracle_bucket: string;
  oracle_private_key_set: boolean;
  oracle_capacity_gb: number | null;
};

const EMPTY: OracleConfig = {
  oracle_tenancy_ocid: "",
  oracle_user_ocid: "",
  oracle_fingerprint: "",
  oracle_region: "ap-mumbai-1",
  oracle_namespace: "",
  oracle_bucket: "",
  oracle_private_key_set: false,
  oracle_capacity_gb: null,
};

function mask(s: string, head = 6, tail = 4) {
  if (!s) return "—";
  if (s.length <= head + tail + 3) return s;
  return `${s.slice(0, head)}••••${s.slice(-tail)}`;
}

function hasAllRequired(c: OracleConfig) {
  return !!(c.oracle_tenancy_ocid && c.oracle_user_ocid && c.oracle_fingerprint &&
            c.oracle_region && c.oracle_namespace && c.oracle_bucket && c.oracle_private_key_set);
}

function formatBytes(n: number): string {
  if (!n || n < 1024) return `${n} B`;
  const units = ["KB", "MB", "GB", "TB", "PB"];
  let v = n / 1024, i = 0;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(v >= 100 ? 0 : v >= 10 ? 1 : 2)} ${units[i]}`;
}

function StorageGauge({
  usage, capacityGb, loading, onRefresh, disabled,
}: {
  usage: { bytes: number; count: number; truncated: boolean } | null;
  capacityGb: number | null;
  loading: boolean;
  onRefresh: () => void;
  disabled: boolean;
}) {
  const capacityBytes = capacityGb ? capacityGb * 1024 ** 3 : 0;
  const usedBytes = usage?.bytes ?? 0;
  const pct = capacityBytes > 0 ? Math.min(100, (usedBytes / capacityBytes) * 100) : 0;
  const tier = pct >= 90 ? "red" : pct >= 70 ? "yellow" : "green";
  const barColor =
    tier === "red" ? "bg-gradient-to-r from-rose-500 to-red-600" :
    tier === "yellow" ? "bg-gradient-to-r from-amber-400 to-orange-500" :
    "bg-gradient-to-r from-emerald-400 to-cyan-400";
  const ringColor =
    tier === "red" ? "text-red-400" :
    tier === "yellow" ? "text-amber-400" :
    "text-emerald-400";
  const labelTone =
    tier === "red" ? "bg-red-500/15 text-red-400 border-red-500/30" :
    tier === "yellow" ? "bg-amber-500/15 text-amber-400 border-amber-500/30" :
    "bg-emerald-500/15 text-emerald-400 border-emerald-500/30";

  return (
    <div className="rounded-2xl border border-border/50 bg-secondary/20 p-5 space-y-4">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Bucket usage</div>
          <div className={cn("font-display text-2xl font-bold mt-1", ringColor)}>
            {capacityBytes > 0 ? `${pct.toFixed(1)}%` : "—"}
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            {usage ? (
              <>
                {formatBytes(usedBytes)}
                {capacityBytes > 0 ? ` of ${formatBytes(capacityBytes)}` : ""}
                {" · "}{usage.count.toLocaleString()} objects
                {usage.truncated ? " (sampled)" : ""}
              </>
            ) : (
              capacityGb ? "No usage data yet" : "Set Bucket Capacity in credentials to enable gauge"
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {capacityBytes > 0 && (
            <span className={cn("inline-flex items-center px-2.5 py-1 rounded-full border text-[11px] font-semibold uppercase tracking-wider", labelTone)}>
              {tier === "red" ? "Critical" : tier === "yellow" ? "Warning" : "Healthy"}
            </span>
          )}
          <button
            onClick={onRefresh}
            disabled={loading || disabled}
            className="h-9 px-3 rounded-lg border border-border bg-secondary/40 hover:bg-secondary text-xs font-semibold inline-flex items-center gap-1.5 disabled:opacity-50"
          >
            {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
            Refresh
          </button>
        </div>
      </div>

      <div className="relative h-3 rounded-full bg-secondary/60 overflow-hidden border border-border/40">
        <div
          className={cn("absolute inset-y-0 left-0 transition-[width] duration-700 ease-out", barColor)}
          style={{ width: `${capacityBytes > 0 ? pct : 0}%` }}
        />
        {/* threshold ticks at 70% and 90% */}
        <div className="absolute inset-y-0 w-px bg-foreground/20" style={{ left: "70%" }} />
        <div className="absolute inset-y-0 w-px bg-foreground/30" style={{ left: "90%" }} />
      </div>
      <div className="flex justify-between text-[10px] uppercase tracking-wider text-muted-foreground">
        <span>0</span><span>70% warn</span><span>90% crit</span><span>{capacityGb ? `${capacityGb} GB` : "—"}</span>
      </div>
    </div>
  );
}

export default function OracleStorageMonitor() {
  const [cfg, setCfg] = useState<OracleConfig>(EMPTY);
  const [draft, setDraft] = useState<OracleConfig>(EMPTY);
  const [pem, setPem] = useState("");
  const [showPem, setShowPem] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [verified, setVerified] = useState<null | boolean>(null);
  const [verifyMsg, setVerifyMsg] = useState<string>("");
  const [diagnosis, setDiagnosis] = useState<Diagnosis | null>(null);
  const [pemHint, setPemHint] = useState<{ tone: "ok" | "warn" | "err"; text: string } | null>(null);

  const [editing, setEditing] = useState(false);
  const [parUrl, setParUrl] = useState<string | null>(null);
  const [creatingPar, setCreatingPar] = useState(false);

  const [usage, setUsage] = useState<{ bytes: number; count: number; truncated: boolean } | null>(null);
  const [loadingUsage, setLoadingUsage] = useState(false);

  const load = async () => {
    const { data } = await supabase
      .from("site_config")
      .select("oracle_tenancy_ocid, oracle_user_ocid, oracle_fingerprint, oracle_region, oracle_namespace, oracle_bucket, oracle_private_key_set, oracle_capacity_gb")
      .eq("id", true)
      .maybeSingle();
    const next: OracleConfig = data ? {
      oracle_tenancy_ocid: data.oracle_tenancy_ocid ?? "",
      oracle_user_ocid: data.oracle_user_ocid ?? "",
      oracle_fingerprint: data.oracle_fingerprint ?? "",
      oracle_region: data.oracle_region ?? "ap-mumbai-1",
      oracle_namespace: data.oracle_namespace ?? "",
      oracle_bucket: data.oracle_bucket ?? "",
      oracle_private_key_set: !!data.oracle_private_key_set,
      oracle_capacity_gb: data.oracle_capacity_gb != null ? Number(data.oracle_capacity_gb) : null,
    } : EMPTY;
    setCfg(next);
    setDraft(next);
    setEditing(!hasAllRequired(next));
    setLoading(false);
  };

  const fetchUsage = async (silent = false) => {
    setLoadingUsage(true);
    const { data, error } = await supabase.functions.invoke("oracle-proxy", { body: { action: "usage" } });
    setLoadingUsage(false);
    if (error || !data?.ok) {
      if (!silent) toast.error("Could not read bucket usage", { description: error?.message ?? data?.error });
      return;
    }
    setUsage({ bytes: Number(data.totalBytes ?? 0), count: Number(data.objectCount ?? 0), truncated: !!data.truncated });
  };

  const runTest = async (silent = false): Promise<boolean> => {
    setTesting(true);
    const { data, error } = await supabase.functions.invoke("oracle-proxy", { body: { action: "test" } });
    setTesting(false);
    const ok = !error && !!data?.ok;
    setVerified(ok);
    if (ok) {
      setVerifyMsg(`Reached bucket "${data.bucket}" in ${data.region}`);
      setDiagnosis(null);
      if (!silent) toast.success("Oracle connection verified");
    } else {
      const raw = data?.error ?? error?.message ?? "Unknown error";
      const dx = diagnose(raw, data?.status);
      setVerifyMsg(raw);
      setDiagnosis(dx);
      if (!silent) toast.error(dx.title, { description: dx.fix });
    }
    return ok;
  };


  useEffect(() => {
    (async () => {
      await load();
      // Auto-verify in the background if fully configured
      // (do not toast on the silent first run).
    })();
  }, []);

  useEffect(() => {
    if (!loading && !editing && hasAllRequired(cfg) && verified === null) {
      runTest(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading, editing, cfg]);

  useEffect(() => {
    if (verified === true && usage === null) {
      fetchUsage(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [verified]);

  const save = async () => {
    // Light client-side validation
    const required: Array<[keyof OracleConfig, string]> = [
      ["oracle_tenancy_ocid", "Tenancy OCID"],
      ["oracle_user_ocid", "User OCID"],
      ["oracle_fingerprint", "Fingerprint"],
      ["oracle_region", "Region"],
      ["oracle_namespace", "Namespace"],
      ["oracle_bucket", "Bucket"],
    ];
    for (const [k, label] of required) {
      if (!String(draft[k] ?? "").trim()) {
        toast.error(`${label} is required`);
        return;
      }
    }
    const trimmedPem = pem.trim();
    if (trimmedPem) {
      const fmt = autoFormatPem(trimmedPem);
      if (!fmt.valid) {
        toast.error("Private key looks malformed", { description: fmt.reason ?? "Click Auto-format key first." });
        return;
      }
      toast.error("Private key must be set as the ORACLE_PRIVATE_KEY backend secret", {
        description: "For security, the PEM is never stored in the database. Open Backend → Secrets and paste the auto-formatted key there.",
      });
      return;
    }


    setSaving(true);
    const payload: Record<string, unknown> = { id: true, ...draft };
    const { error } = await supabase.from("site_config").upsert(payload, { onConflict: "id" });
    if (error) { setSaving(false); toast.error(error.message); return; }
    setPem(""); setShowPem(false);
    await load();
    setSaving(false);
    // Auto-validate after save
    const ok = await runTest(false);
    if (ok) setEditing(false);
  };

  const createPar = async () => {
    setCreatingPar(true); setParUrl(null);
    const { data, error } = await supabase.functions.invoke("oracle-proxy", {
      body: { action: "create-par", name: `camera-ingest-${Date.now()}`, objectName: "ingest/", accessType: "AnyObjectWrite" },
    });
    setCreatingPar(false);
    if (error || !data?.ok) { toast.error(error?.message ?? data?.error ?? "Failed to create PAR"); return; }
    setParUrl(data.url);
    toast.success("PAR URL created (valid for 7 days)");
  };

  const StatusBadge = () => {
    if (loading) return null;
    if (!hasAllRequired(cfg)) {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/15 text-amber-400 text-[11px] font-semibold uppercase tracking-wider">
          <ShieldAlert className="w-3 h-3" /> Setup required
        </span>
      );
    }
    if (verified === true) {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-400 text-[11px] font-semibold uppercase tracking-wider">
          <ShieldCheck className="w-3 h-3" /> Verified
        </span>
      );
    }
    if (verified === false) {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-destructive/15 text-destructive text-[11px] font-semibold uppercase tracking-wider">
          <XCircle className="w-3 h-3" /> Verification failed
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-secondary/60 text-muted-foreground text-[11px] font-semibold uppercase tracking-wider">
        <Loader2 className="w-3 h-3 animate-spin" /> Verifying…
      </span>
    );
  };

  return (
    <div className="glass rounded-2xl p-6 space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h2 className="font-display text-2xl font-bold flex items-center gap-2">
            <Cloud className="w-5 h-5 text-accent" /> Oracle OCI Storage
          </h2>
          <p className="text-xs text-muted-foreground mt-1">
            Configure your Oracle Cloud bucket. Private key is stored as a backend secret — never sent to the browser.
          </p>
        </div>
        <StatusBadge />
      </div>

      {loading ? (
        <div className="py-10 grid place-items-center"><Loader2 className="w-5 h-5 animate-spin text-primary" /></div>
      ) : editing ? (
        <>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Tenancy OCID" value={draft.oracle_tenancy_ocid} onChange={v => setDraft({ ...draft, oracle_tenancy_ocid: v })} placeholder="ocid1.tenancy.oc1..." />
            <Field label="User OCID" value={draft.oracle_user_ocid} onChange={v => setDraft({ ...draft, oracle_user_ocid: v })} placeholder="ocid1.user.oc1..." />
            <Field label="Key Fingerprint" value={draft.oracle_fingerprint} onChange={v => setDraft({ ...draft, oracle_fingerprint: v })} placeholder="aa:bb:cc:..." />
            <Field label="Region" value={draft.oracle_region} onChange={v => setDraft({ ...draft, oracle_region: v })} placeholder="ap-mumbai-1" />
            <Field label="Namespace" value={draft.oracle_namespace} onChange={v => setDraft({ ...draft, oracle_namespace: v })} placeholder="axxxxxxxxxx" />
            <Field label="Bucket" value={draft.oracle_bucket} onChange={v => setDraft({ ...draft, oracle_bucket: v })} placeholder="streamvista-media" />
            <Field
              label="Bucket Capacity (GB) — for usage gauge"
              value={draft.oracle_capacity_gb != null ? String(draft.oracle_capacity_gb) : ""}
              onChange={v => setDraft({ ...draft, oracle_capacity_gb: v.trim() === "" ? null : Number(v) })}
              placeholder="e.g. 1024"
            />
          </div>

          <MissingFieldsChecklist draft={draft} pemPresentOnFile={cfg.oracle_private_key_set} />

          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs uppercase tracking-wider text-muted-foreground flex items-center gap-2">
                <KeyRound className="w-3.5 h-3.5" /> Oracle Private Key (PEM, PKCS#8)
              </label>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => {
                    const fmt = autoFormatPem(pem);
                    if (!pem.trim()) {
                      setPemHint({ tone: "warn", text: "Paste a PEM first, then auto-format." });
                      return;
                    }
                    setPem(fmt.pem);
                    if (fmt.valid) {
                      setPemHint({ tone: "ok", text: fmt.changed ? "Key cleaned up and BEGIN/END headers ensured." : "Key already well-formed." });
                      toast.success("Private key auto-formatted");
                    } else {
                      setPemHint({ tone: "err", text: fmt.reason ?? "Unable to parse PEM." });
                    }
                  }}
                  className="text-[11px] uppercase tracking-wider text-accent hover:underline inline-flex items-center gap-1"
                >
                  <Wand2 className="w-3 h-3" /> Auto-format key
                </button>
                <button type="button" onClick={() => setShowPem(s => !s)}
                  className="text-[11px] uppercase tracking-wider text-accent hover:underline">
                  {showPem ? "Hide" : "Show"}
                </button>
              </div>
            </div>
            <textarea
              value={pem}
              onChange={e => { setPem(e.target.value); setPemHint(null); }}
              onBlur={() => {
                if (!pem.trim()) return;
                const fmt = autoFormatPem(pem);
                setPemHint(fmt.valid
                  ? { tone: "ok", text: "PEM structure looks valid." }
                  : { tone: "err", text: fmt.reason ?? "Invalid PEM." });
              }}
              placeholder={cfg.oracle_private_key_set
                ? "•••••••••• key on file. Paste a new PEM only to rotate."
                : "-----BEGIN PRIVATE KEY-----\nMIIEv...\n-----END PRIVATE KEY-----"}
              rows={6}
              spellCheck={false}
              autoComplete="off"
              className={cn(
                "w-full px-3 py-2 rounded-xl bg-secondary/40 border border-border/60 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-accent/40 resize-y",
                showPem ? "" : "[-webkit-text-security:disc]",
              )}
              style={showPem ? undefined : ({ WebkitTextSecurity: "disc" } as React.CSSProperties)}
            />
            {pemHint && (
              <p className={cn(
                "text-[11px] inline-flex items-center gap-1.5",
                pemHint.tone === "ok" && "text-emerald-400",
                pemHint.tone === "warn" && "text-amber-400",
                pemHint.tone === "err" && "text-destructive",
              )}>
                {pemHint.tone === "ok" ? <CheckCircle2 className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                {pemHint.text}
              </p>
            )}
            <p className="text-[11px] text-muted-foreground inline-flex items-center gap-1.5">
              <Lock className="w-3 h-3" /> Stored as the ORACLE_PRIVATE_KEY backend secret — never written to the database or sent to browsers.
            </p>
          </div>


          <div className="flex flex-wrap gap-2">
            <button
              onClick={save}
              disabled={saving || testing}
              className="h-11 px-5 rounded-xl bg-gradient-primary text-primary-foreground font-semibold glow-primary text-sm disabled:opacity-60 inline-flex items-center gap-2"
            >
              {(saving || testing) && <Loader2 className="w-4 h-4 animate-spin" />}
              {saving ? "Saving…" : testing ? "Verifying…" : "Save & verify"}
            </button>
            {hasAllRequired(cfg) && (
              <button
                onClick={() => { setDraft(cfg); setPem(""); setEditing(false); }}
                className="h-11 px-5 rounded-xl border border-border bg-secondary/40 hover:bg-secondary text-sm font-semibold"
              >Cancel</button>
            )}
          </div>
        </>
      ) : (
        <>
          <div className="grid sm:grid-cols-2 gap-3">
            <ReadRow label="Tenancy OCID" value={mask(cfg.oracle_tenancy_ocid, 18, 6)} />
            <ReadRow label="User OCID" value={mask(cfg.oracle_user_ocid, 18, 6)} />
            <ReadRow label="Fingerprint" value={cfg.oracle_fingerprint} />
            <ReadRow label="Region" value={cfg.oracle_region} />
            <ReadRow label="Namespace" value={cfg.oracle_namespace} />
            <ReadRow label="Bucket" value={cfg.oracle_bucket} />
            <ReadRow label="Private key" value={cfg.oracle_private_key_set ? "•••••••• on file" : "not set"} />
          </div>

          <StorageGauge
            usage={usage}
            capacityGb={cfg.oracle_capacity_gb}
            loading={loadingUsage}
            onRefresh={() => fetchUsage(false)}
            disabled={verified !== true}
          />

          {verified === false && (
            <DiagnosisCard dx={diagnosis ?? diagnose(verifyMsg)} raw={verifyMsg} onEdit={() => setEditing(true)} onRetry={() => runTest(false)} testing={testing} />
          )}


          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setEditing(true)}
              className="h-11 px-5 rounded-xl border border-accent/40 text-accent hover:bg-accent/10 text-sm font-semibold inline-flex items-center gap-2"
            >
              <Pencil className="w-4 h-4" /> Edit credentials
            </button>
            <button
              onClick={() => runTest(false)}
              disabled={testing}
              className="h-11 px-5 rounded-xl border border-border bg-secondary/40 hover:bg-secondary text-sm font-semibold inline-flex items-center gap-2"
            >
              {testing ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
              Re-test connection
            </button>
            <button
              onClick={createPar}
              disabled={creatingPar}
              className="h-11 px-5 rounded-xl border border-border bg-secondary/40 hover:bg-secondary text-sm font-semibold inline-flex items-center gap-2"
            >
              {creatingPar ? <Loader2 className="w-4 h-4 animate-spin" /> : <LinkIcon className="w-4 h-4" />}
              Create Camera Ingest URL (PAR)
            </button>
          </div>

          {parUrl && (
            <div className="rounded-xl border border-accent/40 bg-accent/5 p-3 text-xs">
              <div className="flex items-center justify-between gap-2 mb-1">
                <span className="font-semibold">Pre-Authenticated Request URL (write-only, 7 days)</span>
                <button
                  onClick={() => { navigator.clipboard.writeText(parUrl); toast.success("Copied"); }}
                  className="inline-flex items-center gap-1 text-accent hover:underline"
                ><Copy className="w-3 h-3" /> Copy</button>
              </div>
              <p className="font-mono break-all">{parUrl}</p>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function Field({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <div className="space-y-1.5">
      <label className="text-xs uppercase tracking-wider text-muted-foreground">{label}</label>
      <input
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        autoComplete="off"
        spellCheck={false}
        className="w-full h-11 px-3 rounded-xl bg-secondary/40 border border-border/60 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-accent/40"
      />
    </div>
  );
}

function ReadRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-border/40 bg-secondary/20 px-3 py-2.5">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="font-mono text-foreground text-[13px] mt-0.5 truncate">{value || "—"}</div>
    </div>
  );
}

function MissingFieldsChecklist({ draft, pemPresentOnFile }: { draft: OracleConfig; pemPresentOnFile: boolean }) {
  const items: Array<{ label: string; ok: boolean; hint: string }> = [
    { label: "Tenancy OCID", ok: !!draft.oracle_tenancy_ocid.trim(), hint: "OCI Console → Profile → Tenancy" },
    { label: "User OCID", ok: !!draft.oracle_user_ocid.trim(), hint: "OCI Console → Profile → User Settings" },
    { label: "Fingerprint", ok: /^[a-f0-9:]{20,}$/i.test(draft.oracle_fingerprint.trim()), hint: "Format: aa:bb:cc:… (colon-separated hex)" },
    { label: "Region", ok: /^[a-z]{2}-[a-z]+-\d$/.test(draft.oracle_region.trim()), hint: "e.g. ap-mumbai-1" },
    { label: "Namespace", ok: !!draft.oracle_namespace.trim(), hint: "Object Storage Namespace (under Tenancy)" },
    { label: "Bucket", ok: !!draft.oracle_bucket.trim(), hint: "Exact bucket name in the chosen region" },
    { label: "Private key (backend secret)", ok: pemPresentOnFile, hint: "Stored as ORACLE_PRIVATE_KEY in Backend → Secrets" },
  ];
  const missing = items.filter(i => !i.ok);
  if (missing.length === 0) return null;
  return (
    <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-3 text-xs">
      <div className="flex items-center gap-1.5 font-semibold text-amber-400 mb-2">
        <ShieldAlert className="w-3.5 h-3.5" /> {missing.length} field{missing.length > 1 ? "s" : ""} still need attention
      </div>
      <ul className="space-y-1">
        {missing.map(m => (
          <li key={m.label} className="flex items-start gap-2">
            <XCircle className="w-3 h-3 text-amber-400 shrink-0 mt-0.5" />
            <span><span className="font-semibold">{m.label}</span> — <span className="text-muted-foreground">{m.hint}</span></span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function DiagnosisCard({
  dx, raw, onEdit, onRetry, testing,
}: { dx: Diagnosis; raw: string; onEdit: () => void; onRetry: () => void; testing: boolean }) {
  return (
    <div className="rounded-xl border border-destructive/40 bg-destructive/10 p-4 text-xs space-y-2">
      <div className="flex items-start gap-2">
        <AlertTriangle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
        <div className="flex-1 min-w-0">
          <div className="font-semibold text-destructive text-sm">{dx.title}</div>
          <div className="text-muted-foreground mt-1">{dx.detail}</div>
          <div className="mt-2 text-foreground"><span className="font-semibold">Fix:</span> {dx.fix}</div>
        </div>
      </div>
      <details className="text-[11px] text-muted-foreground">
        <summary className="cursor-pointer hover:text-foreground">Raw response</summary>
        <pre className="mt-1 whitespace-pre-wrap break-all font-mono">{raw}</pre>
      </details>
      <div className="flex flex-wrap gap-2 pt-1">
        <button onClick={onRetry} disabled={testing}
          className="h-8 px-3 rounded-lg border border-border bg-secondary/40 hover:bg-secondary text-[11px] font-semibold inline-flex items-center gap-1.5 disabled:opacity-50">
          {testing ? <Loader2 className="w-3 h-3 animate-spin" /> : <CheckCircle2 className="w-3 h-3" />} Re-test now
        </button>
        <button onClick={onEdit}
          className="h-8 px-3 rounded-lg border border-accent/40 text-accent hover:bg-accent/10 text-[11px] font-semibold inline-flex items-center gap-1.5">
          <Pencil className="w-3 h-3" /> Edit credentials
        </button>
        <span className="inline-flex items-center gap-1 text-[11px] text-muted-foreground ml-auto">
          <Lock className="w-3 h-3" /> Saved config preserved
        </span>
      </div>
    </div>
  );
}


